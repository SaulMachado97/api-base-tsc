export interface Auth{
    user: string;
    password: string;
}