export interface Car{
    color:string;
    typeGas:'gasoline|electric';
    year: number;
    factory: string;
    price: number;
}